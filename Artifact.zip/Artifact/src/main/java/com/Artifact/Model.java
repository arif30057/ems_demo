package com.Artifact;

import lombok.*;
import java.io.File;

@Data
// this is needed so that while to transfer the fields into the entity class, in the service operation, we can get
//the fields using getter(). This getter is supplied by this annotation.
public class Model {
    private String name;
    private String image;
    private String pdf;
    private String zipped;
}
