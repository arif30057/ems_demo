package com.Artifact;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
//@RequestMapping("")
@RequiredArgsConstructor

public class Controller {

    private final Repository repo;

    @PostMapping
    public ResponseEntity<EntityClass> uploadFile(@RequestBody Model model){
        // this portion can also be done in another class, service. then use here.
        EntityClass newEntity = EntityClass.builder()
                .name(model.getName())
                .image(model.getImage())
                .pdf(model.getPdf())
                .zipped(model.getZipped())
                .build();
        return new ResponseEntity<>( repo.save(newEntity) , HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<EntityClass>> showAllEntity(){
        return new ResponseEntity<>(repo.findAll() , HttpStatus.OK);
    }
}
