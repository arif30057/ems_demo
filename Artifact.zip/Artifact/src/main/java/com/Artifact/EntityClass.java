package com.Artifact;

import jakarta.persistence.*;
import lombok.*;
import java.io.File;

@Entity
// this is a must for JpaRepository to create a table for this class.

//@Table(name = "bla_bla_bla")
// this is a optional feature, if you only intend to custom set the table name. Else the table name will be the class name.

@Builder
//This is needed so that, while creating a object of this class, we can use the .builder().build() functionality.
// Else we can also use the objectName.getter() and setter(), as we have already declared the @Data annotation which gives all the getter & setters.

@Data
@AllArgsConstructor
@NoArgsConstructor
//All the 3 above annotations are must for JpaRepository to work. Else JpaRepository can store values into the database
// But can't show/find data from the database, can't construct data to return while save() , find..() methods are called.

public class EntityClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long classId;

    private String name;
    private String image;
    private String pdf;
    private String zipped;
}
