package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.service.*;
import lombok.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor

public class RegistrationLoginController {

    private final RegistrationLoginService authService;

    //All these methods are by default public, so no need to explicitly mention.
    @PostMapping("/register/admin")
    ResponseEntity<Object> createAdmin(@RequestBody CreateAdmin admin){
        return authService.createAdmin(admin);
    }

    @PostMapping("/register/trainer")
    ResponseEntity<Object> createTrainer(@RequestBody CreateTrainer trainer){
        return authService.createTrainer(trainer);
    }

    @PostMapping("/register/trainee")
    ResponseEntity<Object> createTrainee(@RequestBody CreateTrainee trainee){
        return authService.createTrainee(trainee);
    }

    @PostMapping("/login")
    ResponseEntity<String> loginUser(@RequestBody LoginRequest login){
        return authService.loginUser(login);
    }

}
