package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class TaskCreateModel {

    private String taskTitle;
    private String taskType;
    @JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-MM-yyyy") // remove this for frontend.
    private Date taskDate;
//    private File questionFile;

}
