package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.model.*;
import com.example.demo.repository.*;
import lombok.*;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor

public class BatchService {

    private final BatchRepository batchRepo;
    private final TraineeRepository traineeRepo;
    private final TrainerRepository trainerRepo;

    public ResponseEntity<Batch> createBatch(BatchCreate batch) {

        if (batchRepo.findByBatchName(batch.getBatchName()) != null) {
            throw new RuntimeException("Batch name not available.");
        }
        else {
            Set<Trainee> newTrainees = new HashSet<>();
            for (Long ids : batch.getTraineeIds()) {
//                if( traineeRepo.findById(ids).isPresent() ){
                newTrainees.add(traineeRepo.findById(ids).get());
//                }
            }
            Set<Trainer> newTrainers = new HashSet<>();
            for (Long ids : batch.getTrainerIds()) {
//                if( trainerRepo.findById(ids).isPresent() ){
                newTrainers.add(trainerRepo.findById(ids).get());
//                }
            }
            Batch newBatch = Batch.builder()
                    .batchName(batch.getBatchName())
                    .startDate(batch.getStartDate())
                    .trainees(newTrainees)
                    .trainers(newTrainers)
                    .build();
            Batch savedBatch = batchRepo.save(newBatch);

//            for( Trainee updatedTrainee : newTrainees ){
//                updatedTrainee.setBatch(savedBatch);
//                traineeRepo.save(updatedTrainee);
//            }//also setting the batch info into all the trainee's record;
//
//            for( Trainer updatedTrainer : newTrainers ){
//                Set<Batch> updatesBatches = updatedTrainer.getBatches();
//                updatesBatches.add(savedBatch);
//                updatedTrainer.setBatches(updatesBatches);
//                trainerRepo.save(updatedTrainer);//------------------------------
//            }
            return new ResponseEntity<>(savedBatch, HttpStatus.CREATED);//return ResponseEntity.ok( batchRepo.save(newBatch) );
        }

    }

    public ResponseEntity<List<Batch>> viewAllBatches() {

        return new ResponseEntity<>( batchRepo.findAll() , HttpStatus.OK);

    }

    public ResponseEntity<Batch> findBatchByBatchId(Long batchId) {

        return new ResponseEntity<>( batchRepo.findById(batchId).orElseThrow() , HttpStatus.OK);

        //this orElseThrow() method is used for Optional type of data only, and this handles the corner case of if data is not found.
        //Then it throws an exception with a message. If this is used then the .get() need not to be used.
        //The .get() method forces to set the returned value into the object. Even if data not found, all fields are set to null.

//        return ResponseEntity.ok( batchRepo.findById( batchId).get() );   //instead of .get() we also can use .orElseThrow()

        // In this case no need to create a NEW ResponseEntity. But this only works in case of HttpStatus->OK
        //But in case of others, like CREATED/NOT_FOUND then, these don't work.

    }


}
